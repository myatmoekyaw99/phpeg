<!DOCTYPE html>
<html>
<body>

<?php
$txt = "Hello world!";
$x = 5;
$y = 10.5;
$txt2 = "W3Schools.com";

echo $txt;
echo "<br>";
echo $x;
echo "<br>";
echo $y;
echo "<br>";
echo "This ", "string ", "was ", "made ", "with multiple parameters.";
echo "<br>";
echo "Study PHP at " . $txt2 . "<br>";

// Cast float to int
$x = 235.768;
$int_cast = (int)$x;
echo $int_cast;

?>

</body>
</html>
