<!DOCTYPE html>
<html>
    <body>

        <?php
        echo(min(0, 150, 30, 0, -8, -200) . "<br>");
        echo(max(300, 150, 30, 20, -8, -200));
        echo("<br>".abs(-6.7)); 
        echo("<br>".rand(10, 100));

        echo "<br>";
        echo(round(0.60)); 
        echo(round(0.49)); 

        // case-insensitive constant name
        define("GREETING", "Welcome to W3Schools.com!", true);
        echo greeting;

        echo "<br>";
        define("fruit",["mango","strawberry","apple","orange"]);
        echo fruit[2];

        echo "<br>";
        $txt1 = "This is ";
        $txt2 = " something about you!";
        echo $txt1 . $txt2;
        echo "<br>";
        $txt1 .= $txt2;
        echo $txt1;

        $x = 5;  
        $y = 10;
        echo "<br>";

        echo ($x <=> $y); // returns -1 because $x is less than $y
        echo "<br>";

        $d = 10;
        $v = 10;
        echo($d <=> $v);

        $x = array("a" => "red", "b" => "green");  
        $y = array("c" => "blue", "d" => "yellow");  
        var_dump($x == $y);
        echo("<br>");

        echo $status = (empty($user)) ? "anonymous" : "logged in";
        echo("<br>");

        $user = "John Doe";  echo $status = (empty($user)) ? "anonymous" : "logged in"; echo("<br>");

        echo $user = $_GET["user"] ?? "anonymous"; echo("<br>");

        $color="blue"; echo $color = $color ?? "red";


        ?>
        
    </body>
</html>
