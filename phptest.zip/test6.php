<!DOCTYPE html>
<html>
<body>

<?php  
$x = 0;
 
while($x <= 100) {
  echo "The number is: $x <br>";
  $x+=10;
}

$y=1;
do{
    echo "The number is : $y <br>";
    $y++;
}while($y <= 10);

for ($x = 0; $x <= 8; $x++) {
    echo "The number is: $x ";
  }

  echo "<br>";
$age = ["Tim"=>"34","Sam"=>"23","Tom"=>"43","Dam"=>"21"];

foreach($age as $n=>$v){
    echo "$n=$v,";
}

echo "<br>";
for ($x = 1; $x < 8; $x++) {

    if ($x == 3){
        continue;
    }

    if ($x == 5) {
      break;
    }
    echo "The number is: $x <br>";
}
?>  


</body>
</html>
