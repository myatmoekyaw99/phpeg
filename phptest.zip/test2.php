<?php
$y = 1;
function myTest() {
  static $x = 0;
  global $y;
  echo $x;
  echo $y;
  echo "<br>";
  $x++;
}

myTest();
myTest();
myTest();
var_dump($y);

$x = 10.365;
var_dump($x);

echo "<br>";
$x = null;
var_dump($x);

echo "<br>";
$cars=array("Volvo","BMW","Toyota","Audi");
var_dump($cars);

echo "<br>";
$x = "59.85" + 100;
var_dump(is_numeric($x));
echo "<br>";
$x = "Hello";
var_dump(is_numeric($x));
?>