<!DOCTYPE html>
<html>
    <body>

        <?php
        class Fruit {
        function Fruit() {
            $this->name = "Berry";
        }
        }
        // create an object
        $fru = new Fruit();

        // show object properties
        echo $fru->name;

        echo "<br>";
        echo strlen("Hello world!"); 
        echo "<br>";
        echo str_word_count("Hello world!");
        echo "<br>";
        echo strrev("Hello My Friends!");
        echo "<br>";
        echo strpos("Good Mornings!!!","Good");
        echo "<br>";
        echo str_replace("world", "Myat", "Hello world!");

        echo "<br>";
        $x = 10.365;
        var_dump(is_float($x));
        echo "<br>";
        $x = 10365;
        var_dump(is_int($x));
        ?>

    </body>
</html>