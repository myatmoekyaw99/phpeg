<!DOCTYPE html>
<html>
<body>

    <?php
        function familyName($fname) {
        echo "$fname Gibson.<br>";
        }

        familyName("Jani");
        familyName("Hege");
        familyName("Stale");
        familyName("Borge");

        function addNumber(int $v1,int $v2){
            return $v1+$v2;
        }
        echo addNumber(5,"5 day");
        // since strict is NOT enabled "5 days" is changed to int(5), and it will return 10
        
    ?>

</body>
</html>
