<!DOCTYPE html>
<html>
    <body>
        <?php //declare(strict_types=1); // strict requirement

        function setHeight(int $minheight = 70) {
            echo "The height is : $minheight <br>";
          }
          
          setHeight(350);
          setHeight(); // will use the default value of 70
          setHeight(135);
          setHeight(80);

            function addNumbers(float $a, float $b) : float {
            return $a + $b;
            }
            echo addNumbers(1.2, 5.2);

            function addNumberss(float $a, float $b) {
            return (int)($a + $b);
            }
            echo "<br>";
            echo addNumberss(1.2, 5.2);
        ?>
    </body>
</html>
