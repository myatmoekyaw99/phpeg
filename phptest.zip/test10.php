<!DOCTYPE html>
<html>
<body>

    <?php
        $cars = array("Volvo", "BMW", "Toyota","Audi","KIA");
        $arrlength = count($cars);

        for($x = 0; $x < $arrlength; $x++) {
        echo $cars[$x];
        echo "<br>";
        }


        $age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");

            foreach($age as $name => $x_value) {
                echo "Name=" . $name . ", Value=" . $x_value;
                echo "<br>";
            }
    ?>

</body>
</html>
