<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stu_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>