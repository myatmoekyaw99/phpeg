<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 4 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  
  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  <script>
    $(document).ready(function(){
        $('#search').on("keyup input", function(){
            /* Get input value on change */
            var inputVal = $(this).val();
            
            if(inputVal.length){
                $.get("search.php", {term: inputVal}).done(function(data){
                    // Display the returned data in browser
                    $('#tbody1').html(data);
                });
            } 
        });
    });
  </script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>
<?php
include 'config.php';

?>
<div class="jumbotron text-center bg-sceondary" style="margin-bottom:0">
  <h1>WELCOME TO MY GALLERY</h1>
 
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
   <?php
    include 'menu.html';
   ?>
  </div>  
</nav>

<div class="container" style="margin-top:30px">

  <label for="name">Name:</label>
  <input type="text" class="form-control-sm" id="search" placeholder="Enter Item Name" name="search">
  <br><br>
  <div class="row">
  <table class="table table-hover" id="table1">
    <thead>
      <tr>
        <th>No</th>
        <th>Item Name</th>
        <th>Price</th>
        <th>Image</th>
      </tr>
    </thead>
    <tbody id="tbody1">
      <?php
            $sql = "SELECT * FROM item";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
              // output data of each row
              $counter = 0;
              while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".++$counter."</td>";
                echo "<td>{$row['name']}</td><td>{$row['price']}</td><td><img width='80' height='80' src='images/".$row['photo']."' /></td>";
                echo "</tr>";
            }
            } else {
              echo "0 results";
            }
        
    ?>
    </tbody>
  </table>
  </div>
</div>

<div class="jumbotron text-center bg-dark" style="margin-bottom:0">
  <h1 class="text-white">Thank You!!</h1>
</div>


</body>
</html>
