<?php

    include 'config.php';
    if(isset($_REQUEST["term"])){
        // Prepare a select statement
        $sql = "SELECT * FROM item WHERE name LIKE ?";
        
        if($stmt = $conn->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_term);
            
            // Set parameters
            $param_term = $_REQUEST["term"] . '%';
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                $result = $stmt->get_result();
                
                // Check number of rows in the result set
                if ($result->num_rows > 0) {
                    // output data of each row
                    $counter = 0;
                    while($row = $result->fetch_assoc()) {
                      echo "<tr>";
                      echo "<td>".++$counter."</td>";
                      echo "<td>{$row['name']}</td><td>{$row['price']}</td><td><img width='80' height='80' src='images/".$row['photo']."' /></td>";
                      echo "</tr>";
                  }
                  } else {
                    echo "0 results";
                  }
            } else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }
        }
        
        // Close statement
        $stmt->close();
    }
 
    // Close connection
    $conn->close();
?>