<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 4 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>
<?php
include 'config.php';
echo 'Connection  Name'.$servername;
function uploadFile($fileName){
    $target_dir = "images/";
$target_file = $target_dir . basename($_FILES[$fileName]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


  $check = getimagesize($_FILES[$fileName]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }


// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Check file size
if ($_FILES[$fileName]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES[$fileName]["tmp_name"], $target_file)) {
    //echo "The file ". basename( $_FILES["photo"]["name"]). " has been uploaded.";
    return $_FILES[$fileName]["name"];
} else {
    echo "Sorry, there was an error uploading your file.";
  }
}
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
  $fileName= uploadFile("photo");
  $name=$_POST["name"];
  $price= $_POST["price"];
  saveItem($name,$fileName,$price);
  }
  function saveItem($name,$photo,$price){
     global $conn;
    $sql = "insert into item(name,photo,price) values(?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssd", $name, $photo,$price);

// set parameters and execute

$stmt->execute();
header("Location: item_list.php");
  }
?>
<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>WELCOME TO MY GALLERY</h1>
 
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
   <?php
    include 'menu.html';
   ?>
  </div>  
</nav>

<div class="container" style="margin-top:30px">
  <div class="row">
  <form action="<?php $_SERVER['PHP_SELF']  ?>" method="post"  enctype="multipart/form-data">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="name" class="form-control" id="name" placeholder="Enter Item Name" name="name">
    </div>
    <div class="form-group">
      <label for="price">Price:</label>
      <input type="number" class="form-control" id="price" placeholder="Enter Price" name="price">
    </div>
    <div class="form-group">
      <label for="photo">Photo:</label>
      <input type="file" class="form-control" id="photo"  name="photo" />
    </div>
    
    <button type="submit" class="btn btn-primary">Save</button>
  </form>
  </div>
</div>

<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>Thank You!!</h1>
</div>

</body>
</html>
