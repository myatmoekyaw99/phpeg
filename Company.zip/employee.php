<!DOCTYPE html>
<html lang="en">
    <head>
    <title>Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> 

    <script>
            $(document).ready(function(){
            $('#cselect').on('change', function(){
                var companyID = $(this).val();
                if(companyID){
                    $.ajax({
                        type:'POST',
                        url:'dget.php',
                        data:'cid='+companyID,
                        success:function(html){
                            $('#bselect').html(html);
                            $('#dselect').html('<option value="">Select branch first</option>'); 
                        }
                    }); 
                }else{
                    $('#bselect').html('<option value="">Select company first</option>');
                    $('#dselect').html('<option value="">Select branch first</option>'); 
                }
            });
    
            $('#bselect').on('change', function(){
                var branchID = $(this).val();
                if(branchID){
                    $.ajax({
                        type:'POST',
                        url:'dget.php',
                        data:'bid='+branchID,
                        success:function(html){
                        $('#dselect').html(html);
                    }
                }); 
                    }else{
                        $('#dselect').html('<option value="">Select branch first</option>'); 
                    }
            });
     });
        </script>
        <?php
            include 'config.php';
            $sql = "SELECT * FROM company";
            $company = array();
            if ($result = $conn->query($sql)) {
            
                while($row = $result->fetch_array(MYSQLI_ASSOC)) {
                        $company[] = $row;
                }
                
            }
        
        ?>
    </head>
        <body style="background-color:lightgray">
            <?php include 'menu.php';?>
            <div class="container-fluid ">
                <div class="row">
                    <div class="col-6 mx-auto bg-secondary mt-4" >
                        <h2>Create Employee</h2>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

                            <div class="form-group">
                                <label for="ename">Name : </label>
                                <input type="text" class="form-control" id="ename" placeholder="Enter name..." name="ename">
                            </div>
                            <div class="form-group">
                                <label for="eemail">Email : </label>
                                <input type="text" class="form-control" id="eemail" placeholder="Enter email..." name="eemail">
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone  : </label>
                                <input type="text" class="form-control" id="ephone" placeholder="Enter phone...." name="ephone">
                            </div>
                            <div class="form-group">
                                <label for="address">Address : </label>
                                <input type="text" class="form-control" id="eaddress" placeholder="Enter address...." name="eaddress">
                            </div>
                            <div class="form-group">
                        <label for="">Company Name: </label>
                        <select name="company" id="cselect" class="form-control">
                            <option selected disabled>Choose company..</option>
                            <?php
                                if(count($company)>0){
                                    foreach($company as $r){
                                        echo "<option value='".$r['cid']."'>{$r['cname']}</option>";
                                    }
                                }

                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Branch Name: </label>
                        <select name="branch" id="bselect" class="form-control">
                            <!--option selected disabled>Choose branch..</option-->
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Department Name: </label>
                        <select name="department" id="dselect" class="form-control">
                            <!--option selected disabled>Choose department..</option--->
                        </select>
                    </div>
                  
                            <button type="submit" class="btn mb-3 btn-primary" name="submit">Create</button>
                        </form>
                    </div>
                </div>
            </div>
        <hr>

    </body>
</html>
<?php
    include 'config.php';

            function test_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            if ($_SERVER["REQUEST_METHOD"] == "POST") {

                $name = test_input($_POST["ename"]);
                $phone = test_input($_POST["ephone"]);
                $email = test_input($_POST["eemail"]);
                $address=test_input($_POST['eaddress']);
                $cname = test_input($_POST["company"]);
                $bname = test_input($_POST["branch"]);
                $dname=test_input($_POST["department"]);
               
                $sql = "insert into employee(ename,eemail,ephone,eaddress,did,cid,bid) values('$name','$email','$phone','$address','$dname','$cname','$bname')";
                
                if ($conn->query($sql) === TRUE) {
                    echo "Insert successfully";
                } else {
                    echo "Error creating table: " . $conn->error;
                }
            
            $conn->close();
            }
            // sql to create table
    
?>