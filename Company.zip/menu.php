<?php    
    echo "<nav class='navbar navbar-expand-md bg-dark navbar-dark'>";
    
        echo "<span class='navbar-brand'>Hello!</span>";

            echo "<ul class='navbar-nav'>";
            echo "<li class='nav-item'>";
            echo "<a class='nav-link' href='company.php'>Company</a>";
            echo "</li>";
            echo "<li class='nav-item'>";
            echo "<a class='nav-link' href='branch.php'>Branch</a>";
            echo "</li>";
            echo "<li class='nav-item'>";
            echo "<a class='nav-link' href='department.php'>Department</a>";
            echo "</li>";
            echo "<li class='nav-item'>";
            echo "<a class='nav-link' href='employee.php'>Employee</a>";
            echo "</li>";
            echo "<li class='nav-item'>";
            echo "<a class='nav-link' href='show.php'>Show</a>";
            echo "</li>";
            
            echo "</ul>";
    echo "</nav>";
?>