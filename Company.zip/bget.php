<?php
    include 'config.php';
    if(isset($_GET["cid"])){
                    $companyId=$_GET["cid"];
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    
                    $sql = "SELECT * FROM branch where cid='$companyId'";
                    $myArray = array();
                    if ($result = $conn->query($sql)) {
                    
                        while($row = $result->fetch_array(MYSQLI_ASSOC)) {
                                $myArray[] = $row;
                        }
                        echo json_encode($myArray);
                    }
         //$result->close();            
    }
    if(isset($_REQUEST["bid"])){
        $branchId=$_REQUEST["bid"];
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT * FROM department where bid='$branchId'";
        $myArray = array();
        if ($result = $conn->query($sql)) {
        
            while($row1 = $result->fetch_array(MYSQLI_ASSOC)) {
                    $myArray[] = $row1;
            }
            echo json_encode($myArray);
        }
       // $result->close();            
    }
?>