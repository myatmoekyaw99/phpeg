<?php 
// Include the database config file 
include_once 'config.php'; 
 
if($_REQUEST["eid"]){ 
    // Fetch state data based on the specific country 
    $query = "SELECT * FROM employee WHERE eid = ".$_REQUEST["eid"]; 
    $result = $conn->query($query); 
     
    // Generate HTML of state options list 
    if($result->num_rows > 0){ 
        echo "<h2>Employee Detail</h2>"; 
        while($row = $result->fetch_assoc()){  
            echo 'Name :'.$row['ename'].'<br>'; 
            echo 'Phone :'.$row['ephone'].'<br>';
            echo 'E-mail :'.$row['eemail'].'<br>';
            echo 'Address :'.$row['eaddress'].'<br>';
        } 
    }else{ 
        echo 'There is no employee match!!'; 
    } 
}
?>