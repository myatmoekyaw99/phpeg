<?php 
// Include the database config file 
include_once 'config.php'; 
 
if(!empty($_POST["cid"])){ 
    // Fetch state data based on the specific country 
    $query = "SELECT * FROM branch WHERE cid = ".$_POST['cid']; 
    $result = $conn->query($query); 
     
    // Generate HTML of state options list 
    if($result->num_rows > 0){ 
        echo '<option value="">Select Branch</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['bid'].'">'.$row['bname'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Branch not available</option>'; 
    } 
}elseif(!empty($_POST["bid"])){ 
    // Fetch city data based on the specific state 
    $query = "SELECT * FROM department WHERE bid = ".$_POST['bid']; 
    $result = $conn->query($query); 
     
    // Generate HTML of city options list 
    if($result->num_rows > 0){ 
        echo '<option value="">Select Department</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['id'].'">'.$row['dname'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Department not available</option>'; 
    } 
} elseif(!empty($_POST["did"])){ 
    // Fetch city data based on the specific state 
    $query = "SELECT * FROM employee WHERE did = ".$_POST['did']; 
    $result = $conn->query($query); 
     
    // Generate HTML of city options list 
    if($result->num_rows > 0){ 
        echo '<option value="">Select Department</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['eid'].'">'.$row['ename'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Department not available</option>'; 
    } 
} 
?>