<!DOCTYPE html>
<html>
    <head>
    <title>Student Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

        <script>
            $(document).ready(function(){
            $('#cselect').on('change', function(){
                var companyID = $(this).val();
                if(companyID){
                    $.ajax({
                        type:'POST',
                        url:'dget.php',
                        data:'cid='+companyID,
                        success:function(html){
                            $('#bselect').html(html);
                            $('#dselect').html('<option value="">Select branch first</option>'); 
                        }
                    }); 
                }else{
                    $('#bselect').html('<option value="">Select company first</option>');
                    $('#dselect').html('<option value="">Select branch first</option>'); 
                }
            });
    
            $('#bselect').on('change', function(){
                var branchID = $(this).val();
                if(branchID){
                    $.ajax({
                        type:'POST',
                        url:'dget.php',
                        data:'bid='+branchID,
                        success:function(html){
                        $('#dselect').html(html);
                    }
                }); 
                    }else{
                        $('#dselect').html('<option value="">Select branch first</option>'); 
                    }
            });
            $('#dselect').on('change', function(){
                var branchID = $(this).val();
                if(branchID){
                    $.ajax({
                        type:'POST',
                        url:'dget.php',
                        data:'did='+branchID,
                        success:function(html){
                        $('#eselect').html(html);
                    }
                }); 
                    }else{
                        $('#eselect').html('<option value="">Select branch first</option>'); 
                    }
            });
     });
        </script>
        <?php
            include 'config.php';
            $sql = "SELECT * FROM company";
            $company = array();
            if ($result = $conn->query($sql)) {
            
                while($row = $result->fetch_array(MYSQLI_ASSOC)) {
                        $company[] = $row;
                }
                
            }
        
        ?>
    </head>
    <body style="background-color:lightgray">
        <?php include 'menu.php';?>
        
        <div class="container-fluid">
        <div class="row">
            <div class="col-3 mt-3 bg-info">
                <h3>Search List</h3> 
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <div class="form-group">
                        <label for="">Company Name: </label>
                        <select name="company" id="cselect" class="form-control">
                            <option selected disabled>Choose company..</option>
                            <?php
                                if(count($company)>0){
                                    foreach($company as $r){
                                        echo "<option value='".$r['cid']."'>{$r['cname']}</option>";
                                    }
                                }

                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Branch Name: </label>
                        <select name="branch" id="bselect" class="form-control">
                            <!--option selected disabled>Choose branch..</option-->
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Department Name: </label>
                        <select name="department" id="dselect" class="form-control">
                            <!--option selected disabled>Choose department..</option--->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Employee Name: </label>
                        <select name="employee" id="eselect" class="form-control">
                            <!--option selected disabled>Choose department..</option--->
                        </select>
                    </div>
                    <input type="submit" name="show" class="btn btn-dark" value="Show">
                    <br>
                </form>
            </div>
            
            <div class="col-9 mt-3">        
                <table class="table table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Company Name</th>
                            <th>Branch Name</th> 
                            <th>Department Name</th>
                            <th>Employee Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                <?php
                include 'config.php';
                if(isset($_POST["show"]))
                {
                    $c = $_POST["company"];
                    $b = $_POST["branch"];
                    $d = $_POST["department"];
                    $e = $_POST["employee"];
                
                    $sql="SELECT company.cname,branch.bname,department.dname,employee.ename,employee.eid FROM company JOIN department JOIN branch JOIN employee WHERE company.cid=employee.cid and employee.bid=branch.bid and employee.did=department.id and employee.eid={$e}";
                    //$sql = "SELECT company.cname,branch.bname,department.dname FROM company join branch join department on company.cid=".$c." AND branch.bid=".$b." AND department.id=".$d."AND department.cid=company.cid AND company.cid=branch.cid AND branch.bid=department.bid";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        
                        echo "<tr>";
                        echo "<td>{$row['cname']}</td><td>{$row['bname']}</td><td>{$row['dname']}</td><td>{$row['ename']}</td><td><a href='detail_employee.php?eid={$row['eid']}'><input type='submit' name='detail' value='Detail'></a></td>";
                        echo "</tr>";
                    }
                    } else {
                    echo "0 results";
                    }
                }
                
                $conn->close();
                ?>
               
                
                </tbody>
                </table>
                
            </div>
        </div>
        </div>
    </body>
</html>