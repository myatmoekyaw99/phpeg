<!DOCTYPE html>
<html lang="en">
    <head>
    <title>Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    </head>
        <body style="background-color:lightgray">
            <?php include 'menu.php';?>
            <div class="container-fluid ">
                <div class="row">
                    <div class="col-6 mx-auto bg-secondary mt-4" >
                        <h2>Create Company</h2>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

                            <div class="form-group">
                                <label for="name">Name : </label>
                                <input type="text" class="form-control" id="name" placeholder="Enter name..." name="name">
                            </div>

                            <div class="form-group">
                                <label for="add">Address : </label>
                                <input type="text" class="form-control" id="add" placeholder="Enter address...." name="address">
                            </div>

                            <div class="form-group">
                                <label for="mail">E-mail : </label>
                                <input type="text" class="form-control" id="mail" placeholder="Enter e-mail...." name="email">
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone  : </label>
                                <input type="text" class="form-control" id="phone" placeholder="Enter phone...." name="phone">
                            </div>

                            <button type="submit" class="btn mb-3 btn-primary" name="submit">Create</button>
                        </form>
                    </div>
                </div>
            </div>
        <hr>

    </body>
</html>
<?php
    include 'config.php';
            function test_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
        

            if ($_SERVER["REQUEST_METHOD"] == "POST") {

                $name = test_input($_POST["name"]);
                $address = test_input($_POST["address"]);
                $email = test_input($_POST["email"]);
                $phone = test_input($_POST["phone"]);
               
                $sql = "insert into company(cname,address,email,phone) values('$name','$address','$email','$phone')";
                
                if ($conn->query($sql) === TRUE) {
                    echo "Insert successfully";
                } else {
                    echo "Error creating table: " . $conn->error;
                }
            
            $conn->close();
            }
            // sql to create table
    
?>