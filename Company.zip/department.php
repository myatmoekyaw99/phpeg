<!DOCTYPE html>
<html lang="en">
    <head>
    <title>Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> 

    <script>
        $(document).ready(function(){
            $("#companyid").change(function(){
                if($("#companyid").val()!=""){
                    var companyId=this.value;
                
                    $.get("bget.php?cid="+companyId, function(data, status){
        
                        var branchList=JSON.parse(data);
                        console.log(branchList);
                        $("#branch").empty();
                        branchList.forEach(function(val,i){
                            $("#branch").append(
                            '<option value="'+val.bid+'">'+val.bname+'</option>');
                        });
                    });
                }
                
            });
        });
    </script>

    <?php
        include 'config.php';
        $sql = "SELECT * FROM company";
        $company = array();
        if ($result = $conn->query($sql)) {
        
            while($row = $result->fetch_array(MYSQLI_ASSOC)) {
                    $company[] = $row;
            }
           // print_r($company);
        }
        $result->close();
    ?>
    </head>
        <body style="background-color:lightgray">
            <?php include 'menu.php';?>
            <div class="container-fluid ">
                <div class="row">
                    <div class="col-6 mx-auto bg-secondary mt-4" >
                        <h2>Create Department</h2>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

                            <div class="form-group">
                                <label for="dname">Name : </label>
                                <input type="text" class="form-control" id="dname" placeholder="Enter name..." name="dname">
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone  : </label>
                                <input type="text" class="form-control" id="phone" placeholder="Enter phone...." name="phone">
                            </div>

                            <div class="form-group">
                                <label for="">Company Name: </label>
                                <select name="company" id="companyid" class="form-control">
                                    <option selected disabled>Choose company..</option>
                                    <?php
                                        if(count($company)>0){
                                            foreach($company as $r){
                                                echo "<option value='".$r['cid']."'>{$r['cname']}</option>";
                                            }
                                        }

                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="">Branch Name: </label>
                                <select name="branch" id="branch" class="form-control">
                                    <option selected disabled>Choose branch..</option>
                                </select>
                            </div>
                            <button type="submit" class="btn mb-3 btn-primary" name="submit">Create</button>
                        </form>
                    </div>
                </div>
            </div>
        <hr>

    </body>
</html>
<?php
    include 'config.php';

            function test_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            if ($_SERVER["REQUEST_METHOD"] == "POST") {

                $name = test_input($_POST["dname"]);
                $phone = test_input($_POST["phone"]);
                $cname = test_input($_POST["company"]);
                $bname = test_input($_POST["branch"]);
               
                $sql = "insert into department(dname,phone,cid,bid) values('$name','$phone','$cname','$bname')";
                
                if ($conn->query($sql) === TRUE) {
                    echo "Insert successfully";
                } else {
                    echo "Error creating table: " . $conn->error;
                }
            
            $conn->close();
            }
            // sql to create table
    
?>